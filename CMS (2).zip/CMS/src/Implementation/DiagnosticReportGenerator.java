package Implementation;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DiagnosticReportGenerator {
	
	public List<String> generateDailyReport(List<Appointment> appointments, Date date) {

		List<String> report = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String targetDate = sdf.format(date);

		for (Appointment app : appointments) {
			if (sdf.format(app.getDate()).equals(targetDate) && app.getDiagnosticResult() != null) {
				String entry = 
						"--------------------------------------------------------------------"+
						"Customer National ID: " + app.getCustomer().getNationalID() + "\n" +
								"Car Plate Number: " + app.getCar().getPlateNumber() + "\n" +
								"Repair & Diagnostic Notes: " + app.getDiagnosticResult().getIssuesFound() + ", " +
								app.getDiagnosticResult().getRecommendedActions() + "\n" +
								app.getServiceReport().getRepairsPerformed() + ", " +
								app.getServiceReport().getPartsUsed()+ "\n" +
								"Appointment Time: " + app.getSlot().toString();
				report.add(entry);
				
				String fileName = "DiagnosticReport_" + app.getCustomer().getNationalID() + "_" + sdf.format(app.getDate()) + ".txt";
		        try (FileWriter writer = new FileWriter(fileName)) {
		            writer.write(entry);
		            System.out.println("Generated file: " + fileName);
		        } catch (IOException e) {
		            System.out.println("Failed to write file: " + fileName);
		            e.printStackTrace();
		        }
			}
		}
		return report;
	}

}
