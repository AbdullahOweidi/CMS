package Implementation;

import java.sql.Time;
import java.util.Date;

public class Appointment {
	
	private Date date;
	private Time slot;
	private Customer customer;
	private Car car;
	private ServiceReport serviceReport;
	private DiagnosticResult diagnosticResult;

	public DiagnosticResult getDiagnosticResult() {
	    return diagnosticResult;
	}

	public void setDiagnosticResult(DiagnosticResult diagnosticResult) {
	    this.diagnosticResult = diagnosticResult;
	}
	
	public ServiceReport getServiceReport() {
		return serviceReport;
	}

	public void setServiceReport(ServiceReport serviceReport) {
		this.serviceReport = serviceReport;
	}

	public Appointment(Date date, Time slot, Customer customer, Car car) {
        this.date = date;
        this.slot = slot;
        this.customer = customer;
        this.car = car;
    }
	
	public Appointment(Date date, Time slot) {
        this.date = date;
        this.slot = slot;
    }
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getSlot() {
		return slot;
	}
	public void setSlot(Time slot) {
		this.slot = slot;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	
	public boolean schedule(Date date, Time slot, Customer customer, Car car) {
		this.date = date;
        this.slot = slot;
        this.customer = customer;
        this.car = car;
        return true;
	}
	
	public boolean cancel() {
        System.out.println("Appointment canceled for customer: " + customer.getName());
        return true;
    }
	
	

}
