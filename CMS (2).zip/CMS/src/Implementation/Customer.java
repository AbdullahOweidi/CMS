package Implementation;

public class Customer {
	
	private String name;
	private String address;
	private String nationalID;
	private String contactNumber;
	private Car car;
	
	public Customer(String name, String address, String nationalID, String contactNumber, Car car) {
        this.name = name;
        this.address = address;
        this.nationalID = nationalID;
        this.contactNumber = contactNumber;
        this.car = car;
    }
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNationalID() {
		return nationalID;
	}

	public void setNationalID(String nationalID) {
		this.nationalID = nationalID;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public double getDiscount() {
		return 0;
		
	}

}
