package Implementation;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FrontDeskAppointmentService {

//	FrontDeskCustomerService customerService = new FrontDeskCustomerService();
	private List<Appointment> appointments = new ArrayList<>();
	public List<Appointment> getAppointments() {
		return appointments;
	}

	public void setAppointments(List<Appointment> appointments) {
		this.appointments = appointments;
	}

	public boolean scheduleAppointment(Date date, Time slot, String nationalId) {
//		List<Customer> customers = customerService.customers;
		
		Customer matchedCustomer = null;
		
		System.out.println("Hey" + FrontDeskCustomerService.customers.size());
		for (Customer customer : FrontDeskCustomerService.customers) {
//			System.out.println("heyyyyyyyy"+customerService.getCustomers());
			if (customer.getNationalID().equals(nationalId)) {
				matchedCustomer = customer;
				break;
			}
		}

		if (matchedCustomer == null) {
			System.out.println("No customer found with this National ID.");
			return false;
		}

		// Step 2: Get the car from the customer
		Car customerCar = matchedCustomer.getCar();

		// Step 3: Check working hours
		int hour = slot.toLocalTime().getHour();
		if (hour < 9 || hour > 17) {
			System.out.println("Appointment outside working hours.");
			return false;
		}

		// Step 4: Check for double booking
		for (Appointment a : appointments) {
			if (a.getDate().equals(date) && a.getSlot().equals(slot)) {
				System.out.println("Slot already booked.");
				return false;
			}
		}

		// Step 5: Create and store the appointment
		Appointment newAppointment = new Appointment(date, slot, matchedCustomer, customerCar);
		appointments.add(newAppointment);
		System.out.println("Appointment scheduled successfully.");
		return true;
	}

	public void printDailyAppointments (Date date) {

		System.out.println("Appointments for " + date.toString() + ":");
		for (Appointment a : appointments) {
			if (a.getDate().equals(date)) {
				System.out.println("Customer: " + a.getCustomer().getName()
						+ ", Car Plate: " + a.getCar().getPlateNumber()
						+ ", Time Slot: " + a.getSlot());
			}
		}		
	}
}
