package Testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import Implementation.Appointment;
import Implementation.Car;
import Implementation.Customer;
import Implementation.FrontDeskAppointmentService;
import Implementation.FrontDeskCustomerService;
//import Implementation.FrontDeskStaff;

class Method1 {

	@Test
	void validRegisteredCustomer() {
		FrontDeskCustomerService frontDesk = new FrontDeskCustomerService();
        Car car = new Car("USA" , "Toyota", "ABC123");
        Customer customer = new Customer("Ali", "Lebanon", "123456789", "5551234", car);
        boolean result = frontDesk.registerCustomer(customer);
        assertTrue(result);
	}
	
	@Test
	void nullRegisteredCustomer() {
		FrontDeskCustomerService frontDesk = new FrontDeskCustomerService();
        boolean result = frontDesk.registerCustomer(null);
        assertFalse(result);
	}
	
	@Test
	void duplicateCustomer() {
		FrontDeskCustomerService frontDesk = new FrontDeskCustomerService();
        Car car = new Car("USA" , "Toyota", "ABC123");
        Customer customer = new Customer("Ali", "Lebanon", "987654321", "555-5678", car);
        frontDesk.registerCustomer(customer);
        boolean result = frontDesk.registerCustomer(customer);
        assertFalse(result);
	}
	
//	#####################################################################################
	
	@Test
	void testGetAppointmentsAfterScheduling() {
		FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
		FrontDeskCustomerService frontDeskCustomer = new FrontDeskCustomerService();
        Car car = new Car("Germany","BMW", "LMN456");
        Customer customer = new Customer("Ali", "Somalia", "123456", "555-6789", car);
        frontDeskCustomer.registerCustomer(customer);
        Date date = new Date();
        Time time = Time.valueOf("10:00:00");
        frontDesk.scheduleAppointment(date, time, "123456");

        List<Appointment> appointments = frontDesk.getAppointments();
        assertEquals(1, appointments.size());
	}
	
	@Test
	void testEmptyGetAppointments() {
		FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
        List<Appointment> appointments = frontDesk.getAppointments();
        assertEquals(0, appointments.size());
	}
	
	@Test
	public void testGetAppointmentsMultipleAppointments() {
        FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
		FrontDeskCustomerService frontDeskCustomer = new FrontDeskCustomerService();
        
        Date date = new Date();

        Car car1 = new Car("Germany","BMW", "LMN456");
        Car car2 = new Car("Germany","Audi", "LMN456");

        Customer c1 = new Customer("Nora", "Tunisia", "111", "999-111", car1);
        Customer c2 = new Customer("Hana", "Palestine", "222", "999-222", car2);

        frontDeskCustomer.registerCustomer(c1);
        frontDeskCustomer.registerCustomer(c2);

        frontDesk.scheduleAppointment(date, Time.valueOf("09:00:00"), "111");
        frontDesk.scheduleAppointment(date, Time.valueOf("11:00:00"), "222");

        List<Appointment> appointments = frontDesk.getAppointments();
        assertEquals(2, appointments.size());
	}
	
//	##################################################################################
	
	@Test
    public void testScheduleAppointmentsBookedSlot() {
        FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
		FrontDeskCustomerService frontDeskCustomer = new FrontDeskCustomerService();
        
        Date date = new Date();

        Car car1 = new Car("Germany" ,"Audi", "111AAA");
        Car car2 = new Car("Germany" ,"Mercedes", "222BBB");

        Customer c1 = new Customer("Nora", "Brazil", "111", "999-111", car1);
        Customer c2 = new Customer("Hana", "India", "222", "999-222", car2);

        frontDeskCustomer.registerCustomer(c1);
        frontDeskCustomer.registerCustomer(c2);

        frontDesk.scheduleAppointment(date, Time.valueOf("09:00:00"), "111");
        
        assertFalse(frontDesk.scheduleAppointment(date, Time.valueOf("09:00:00"), "222"));
    }
	
	@Test
    public void testScheduleAppointmentValid() {
        FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
		FrontDeskCustomerService frontDeskCustomer = new FrontDeskCustomerService();
        
        Car car = new Car("South Korea" ,"Hyundai", "GH123");
        Customer customer = new Customer("Ziad", "Mexico", "999", "555-9999", car);
        frontDeskCustomer.registerCustomer(customer);

        Date date = new Date();
        Time slot = Time.valueOf("10:00:00");
        boolean result = frontDesk.scheduleAppointment(date, slot, "999");
        assertTrue(result);
    }
	
	@Test
    public void testScheduleAppointmentOutOfWorkingHours() {
        FrontDeskAppointmentService frontDesk = new FrontDeskAppointmentService();
		FrontDeskCustomerService frontDeskCustomer = new FrontDeskCustomerService();
        
        Car car = new Car("South Korea" ,"Hyundai", "GH123");
        Customer customer = new Customer("Ziad", "Mexico", "999", "555-9999", car);
        frontDeskCustomer.registerCustomer(customer);

        Date date = new Date();
        Time slot = Time.valueOf("20:00:00");
        boolean result = frontDesk.scheduleAppointment(date, slot, "999");
        assertFalse(result);
    }
	
	

}
