package Implementation;

import java.util.Date;

public class ServiceReport {
	
	private String repairsPerformed;
	private String partsUsed;
	private Date completionDate;
	public String getRepairsPerformed() {
		return repairsPerformed;
	}
	public void setRepairsPerformed(String repairsPerformed) {
		this.repairsPerformed = repairsPerformed;
	}
	public String getPartsUsed() {
		return partsUsed;
	}
	public void setPartsUsed(String partsUsed) {
		this.partsUsed = partsUsed;
	}
	public Date getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}

}
