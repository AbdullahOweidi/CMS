package Implementation;

public class TechnicianService {
	
	public boolean addDiagnosticResult(Appointment appointment, DiagnosticResult result) {

		if (appointment == null || result == null) {
			return false;
		}
		appointment.setDiagnosticResult(result);
		System.out.println("Diagnostic result added successfully.");
		return true;

	}

}
