package Implementation;

import java.util.List;

public class MechanicAppointmentViewer {
	
	public void viewAppointments(List<Appointment> appointments) {
        System.out.println("Scheduled Appointments:");
        for (Appointment a : appointments) {
        	System.out.println("Customer: " + a.getCustomer().getName() +
                    ", Car Plate: " + a.getCar().getPlateNumber() +
                    ", Time Slot: " + a.getSlot());

                if (a.getServiceReport() != null) {
                    System.out.println("Mechanic notes:");
                    System.out.println("Parts used: " + (a.getServiceReport().getPartsUsed() != null ? a.getServiceReport().getPartsUsed() : "N/A"));
                    System.out.println("Repairs performed: " + (a.getServiceReport().getRepairsPerformed() != null ? a.getServiceReport().getRepairsPerformed() : "N/A"));
                } else {
                    System.out.println("Mechanic notes: No service report available yet.");
                }
        }
    }
}
