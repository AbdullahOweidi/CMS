package Implementation;

import java.util.Date;

public class DiagnosticResult {
	
	private String issuesFound;
	private String recommendedActions;
	private Date diagnosticDate;
	
	
	public String getIssuesFound() {
		return issuesFound;
	}
	public void setIssuesFound(String issuesFound) {
		this.issuesFound = issuesFound;
	}
	public String getRecommendedActions() {
		return recommendedActions;
	}
	public void setRecommendedActions(String recommendedActions) {
		this.recommendedActions = recommendedActions;
	}
	public Date getDiagnosticDate() {
		return diagnosticDate;
	}
	public void setDiagnosticDate(Date diagnosticDate) {
		this.diagnosticDate = diagnosticDate;
	}

}
