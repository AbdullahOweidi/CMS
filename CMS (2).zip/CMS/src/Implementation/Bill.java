package Implementation;

import java.util.Date;

public class Bill {
	
	private double amount;
	private Date issueDate;
	private final double SERVICE_COST = 50.0;
	
	public Bill(Customer customer) {
        this.amount = SERVICE_COST * (1 - customer.getDiscount());
        this.issueDate = new Date(); // Current date
    }
	
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public double calculate (Customer customer) {
		
		return SERVICE_COST * (1 - customer.getDiscount());
//        if (customer instanceof FleetCompanyClient) {
//            return SERVICE_COST * 0.7;
//        } else if (customer instanceof StaffMember) {
//            return SERVICE_COST * 0.5;
//        } else {
//            return SERVICE_COST;
//        }
		
	}

}
