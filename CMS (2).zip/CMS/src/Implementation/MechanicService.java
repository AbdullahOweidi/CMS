package Implementation;

public class MechanicService {
	
	public void addServiceReport(Appointment appointment, ServiceReport report) {

	    // Set the combined repair report string into the appointment
	    appointment.setServiceReport(report);

	    System.out.println("Repair report added successfully.");
	}

}
