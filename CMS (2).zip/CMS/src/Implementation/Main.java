package Implementation;

import java.sql.Time;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
//        FrontDeskStaff frontDesk = new FrontDeskStaff();
//        Mechanic mechanic = new Mechanic();
        TechnicianService technicianService = new TechnicianService();
        DiagnosticReportGenerator reportGenerator = new DiagnosticReportGenerator();
        MechanicService mechanicService = new MechanicService();
        MechanicAppointmentViewer appointmentViewer = new MechanicAppointmentViewer();
        FrontDeskCustomerService customerService = new FrontDeskCustomerService();
        FrontDeskAppointmentService appointmentService = new FrontDeskAppointmentService();
        

        Date today = new Date();

        while (true) {
            System.out.println("\nSelect user role:");
            System.out.println("1. FrontDesk Staff");
            System.out.println("2. Mechanic");
            System.out.println("3. Technician");
            System.out.println("4. Exit");
            System.out.print("Choice: ");
            int roleChoice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (roleChoice == 4) {
                System.out.println("Exiting...");
                break;
            }

            switch (roleChoice) {
                case 1:
                    frontDeskMenu(customerService, appointmentService, scanner, today);
                    break;
                case 2:
                    mechanicMenu(mechanicService , appointmentViewer, appointmentService, scanner);
                    break;
                case 3:
                    technicianMenu(technicianService, reportGenerator , appointmentService, scanner, today);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
        scanner.close();
    }

	 private static void frontDeskMenu(FrontDeskCustomerService customerService,
	     FrontDeskAppointmentService appointmentService,
	     Scanner scanner,
	     Date today
	 ) 
	 
	 {
	     while (true) {
	         System.out.println("\nFrontDesk Menu:");
	         System.out.println("1. Register New Customer and Car");
	         System.out.println("2. Schedule Same-Day Service Appointment");
	         System.out.println("3. Print Daily Appointments");
	         System.out.println("4. Calculate Bill");
	         System.out.println("5. Back to Role Selection");
	         System.out.print("Choice: ");
	         int choice = scanner.nextInt();
	         scanner.nextLine();

	         switch (choice) {
	             case 1:
	                 System.out.print("Enter customer name: ");
	                 String name = scanner.nextLine();

	                 System.out.print("Enter customer address: ");
	                 String address = scanner.nextLine();

	                 System.out.print("Enter customer National ID: ");
	                 String nationalId = scanner.nextLine();

	                 System.out.print("Enter customer Contact number: ");
	                 String contactNumber = scanner.nextLine();

	                 System.out.print("Enter customer's car make: ");
	                 String carMake = scanner.nextLine();

	                 System.out.print("Enter customer's car model: ");
	                 String carModel = scanner.nextLine();

	                 System.out.print("Enter customer's car plate number: ");
	                 String carPlateNumber = scanner.nextLine();

	                 Car newCar = new Car(carMake, carModel, carPlateNumber);
	                 Customer newCustomer = null;

	                 while (true) {
	                     System.out.print("Which type is this customer?:\n1- Private car owner"
	                             + "\n2- Fleet company client\n3- Center staff member\nChoice: ");
	                     String customerType = scanner.nextLine();

	                     if (customerType.equals("1")) {
	                         newCustomer = new PrivateCarOwner(name, address, nationalId, contactNumber, newCar);
	                         break;
	                     } else if (customerType.equals("2")) {
	                         newCustomer = new FleetCompanyClient(name, address, nationalId, contactNumber, newCar);
	                         break;
	                     } else if (customerType.equals("3")) {
	                         newCustomer = new CenterStaffMember(name, address, nationalId, contactNumber, newCar);
	                         break;
	                     } else {
	                         System.out.println("Invalid customer type. Please enter 1, 2, or 3.");
	                     }
	                 }

	                 customerService.registerCustomer(newCustomer);
	                 System.out.println("Customer and car registered successfully.");
	                 break;

	             case 2:
	                 System.out.println("Enter customer national ID: ");
	                 nationalId = scanner.nextLine();

	                 System.out.print("Enter appointment hour (0-23) for today: ");
	                 String slot = scanner.next();
	                 scanner.nextLine();

	                 String fullTimeString = slot + ":00:00";
	                 Time timeSlot = Time.valueOf(fullTimeString);

	                 boolean scheduled = appointmentService.scheduleAppointment(
	                     today,
	                     timeSlot,
	                     nationalId
	                 );

	                 if (scheduled) {
	                     System.out.println("Appointment scheduled successfully at " + today);
	                 } else {
	                     System.out.println("Failed to schedule appointment. Time slot may be occupied.");
	                 }
	                 break;

	             case 3:
	                 appointmentService.printDailyAppointments(today);
	                 break;

	             case 4:
	                 System.out.print("Enter customer National ID to calculate bill: ");
	                 nationalId = scanner.nextLine();

	                 Bill billAmount = customerService.calculateBill(nationalId);
	                 if (billAmount != null && billAmount.getAmount() >= 0) {
	                     System.out.println("Total bill amount for National ID " + nationalId + " is: $" + billAmount.getAmount());
	                 } else {
	                     System.out.println("No customer or service found with that National ID.");
	                 }
	                 break;

	             case 5:
	                 return;

	             default:
	                 System.out.println("Invalid choice.");
	         }
	     }
	 }
    private static void mechanicMenu(MechanicService mechanicService, MechanicAppointmentViewer appointmentViewer, FrontDeskAppointmentService frontDesk, Scanner scanner) {
        while (true) {
            System.out.println("1. Add Service Report");
            System.out.println("2. View Service appointments");
            System.out.println("3. Back to Role Selection");
            System.out.print("Choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    List<Appointment> mechanicAppointments = frontDesk.getAppointments();
                    if (mechanicAppointments.isEmpty()) {
                        System.out.println("No appointments available.");
                        break;
                    }

                    System.out.println("Select an appointment to add a service report:");
                    for (int i = 0; i < mechanicAppointments.size(); i++) {
                        Appointment app = mechanicAppointments.get(i);
                        System.out.println((i + 1) + ". " +
                            app.getCustomer().getName() + " - " +
                            app.getDate() + " at " + app.getSlot());
                    }

                    System.out.print("Enter the appointment number: ");
                    int appIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // consume newline

                    if (appIndex < 0 || appIndex >= mechanicAppointments.size()) {
                        System.out.println("Invalid appointment selected.");
                        break;
                    }

                    Appointment selectedAppointment = mechanicAppointments.get(appIndex);

                    System.out.print("Enter repairs performed: ");
                    String repairs = scanner.nextLine();

                    System.out.print("Enter parts used: ");
                    String parts = scanner.nextLine();

                    ServiceReport report = new ServiceReport();
                    report.setRepairsPerformed(repairs);
                    report.setPartsUsed(parts);

                    mechanicService.addServiceReport(selectedAppointment, report);
                    break;

                case 2:
                    List<Appointment> allAppointments = frontDesk.getAppointments();
                    appointmentViewer.viewAppointments(allAppointments);
                    break;

                case 3:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }


    private static void technicianMenu(TechnicianService technicianService, DiagnosticReportGenerator reportGenerator, FrontDeskAppointmentService frontDesk, Scanner scanner, Date today) {
        while (true) {
            System.out.println("\nTechnician Menu:");
            System.out.println("1. Add Diagnostic Result");
            System.out.println("2. Generate Daily Diagnostic Report");
            System.out.println("3. Back to Role Selection");
            System.out.print("Choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    List<Appointment> appointmentsForDiagnostics = frontDesk.getAppointments();
                    if (appointmentsForDiagnostics.isEmpty()) {
                        System.out.println("No appointments available.");
                        break;
                    }

                    System.out.println("Select an appointment to add diagnostic result:");
                    for (int i = 0; i < appointmentsForDiagnostics.size(); i++) {
                        Appointment app = appointmentsForDiagnostics.get(i);
                        System.out.println((i + 1) + ". " +
                            app.getCustomer().getName() + " - " +
                            app.getDate() + " at " + app.getSlot());
                    }

                    System.out.print("Enter the appointment number: ");
                    int diagIndex = scanner.nextInt() - 1;
                    scanner.nextLine();

                    if (diagIndex < 0 || diagIndex >= appointmentsForDiagnostics.size()) {
                        System.out.println("Invalid appointment selected.");
                        break;
                    }

                    Appointment selectedApp = appointmentsForDiagnostics.get(diagIndex);

                    System.out.print("Enter issues found: ");
                    String issues = scanner.nextLine();

                    System.out.print("Enter recommended actions: ");
                    String actions = scanner.nextLine();

                    DiagnosticResult diagResult = new DiagnosticResult();
                    diagResult.setDiagnosticDate(today);
                    diagResult.setIssuesFound(issues);
                    diagResult.setRecommendedActions(actions);

                    technicianService.addDiagnosticResult(selectedApp, diagResult);
                    System.out.println("Diagnostic result added successfully.");
                    break;

                case 2:
                    List<Appointment> allTechAppointments = frontDesk.getAppointments();
                    List<String> dailyReport = reportGenerator.generateDailyReport(allTechAppointments, today);

                    System.out.println("\n--- Daily Diagnostic Report ---");
                    if (dailyReport.isEmpty()) {
                        System.out.println("No diagnostics available for today.");
                    } else {
                        for (String line : dailyReport) {
                            System.out.println(line);
                        }
                    }
                    break;

                case 3:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }

		
	}

	}
