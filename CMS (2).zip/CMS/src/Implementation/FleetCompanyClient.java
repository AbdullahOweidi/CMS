package Implementation;

public class FleetCompanyClient extends Customer {
	
	 public FleetCompanyClient(String name, String address, String nationalID, String contactNumber, Car car) {
	        super(name, address, nationalID, contactNumber, car);
	    }

	    @Override
	    public double getDiscount() {
	        return 0.30;
	    }

}
