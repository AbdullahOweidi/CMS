package Implementation;

public class PrivateCarOwner extends Customer {
	
	 public PrivateCarOwner(String name, String address, String nationalID, String contactNumber, Car car) {
	        super(name, address, nationalID, contactNumber, car);
	    }

	public double getDiscount() {
		return 0;
		
	}

}
