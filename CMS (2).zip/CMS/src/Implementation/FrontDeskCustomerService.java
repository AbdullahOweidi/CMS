package Implementation;

import java.util.ArrayList;
import java.util.List;

public class FrontDeskCustomerService {
	
	protected static List<Customer> customers = new ArrayList<>();

	public boolean registerCustomer(Customer customer) {
		if (customer == null) { 
			return false;
		}
        
		for (Customer existingCustomer : customers) {
	        if (existingCustomer.getNationalID().equals(customer.getNationalID())) {
	            return false;
	        }
	    }
		
		customers.add(customer);
        return true;
		
	}
	
	public Bill calculateBill(String nationalId) {
		for (Customer customer : customers) {
	        if (customer.getNationalID().equals(nationalId)) {
	            if (customer instanceof PrivateCarOwner) {
	                System.out.println("Customer is a Private Car Owner.");
	            } else if (customer instanceof FleetCompanyClient) {
	                System.out.println("Customer is a Fleet Company Client.");
	            } else {
	                System.out.println("Customer is a Center Staff Member.");
	            }

	            return new Bill(customer);
	        }
	    }

	    // If no customer found
	    System.out.println("Customer with National ID " + nationalId + " not found.");
	    return null;
	}
	
	

}
